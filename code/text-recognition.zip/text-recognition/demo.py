from cv2 import cv2

from preprocess import separate_recognition

if __name__ == '__main__':
    single_img = cv2.imread("16_piece.jpg")  # 读取地址
    single_img_rec_result = separate_recognition(single_img)
    print(single_img_rec_result)
